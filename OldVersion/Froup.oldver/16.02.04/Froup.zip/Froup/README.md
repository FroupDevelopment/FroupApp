# Froup
An application aimed at streamlining focus grouping
